****************************************
*READ ME
****************************************
1��To change the executable file permissions:
chmod +x ./scripts/*
chmod +x ./scripts/gnuplot/bin/*
2��call scripts from parent directory of scripts/, for example:
./scripts/run_status.sh -d <test duration> -r <report directory>